from flask import Flask, render_template, request, redirect, url_for, session, jsonify, flash, send_from_directory
import sqlite3, random, string, os, time
from datetime import datetime, timedelta
from werkzeug.utils import secure_filename
from functools import wraps

app = Flask(__name__)
app.secret_key = 'acs_super_secret_key_2024'

UPLOAD_FOLDER = os.path.join('static', 'uploads')
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif', 'pdf'}
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

# ── Database Setup ───────────────────────────────────────────────────────────

def get_db():
    conn = sqlite3.connect('database.db')
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    with get_db() as conn:
        conn.executescript('''
            CREATE TABLE IF NOT EXISTS otps (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                mobile TEXT NOT NULL,
                otp TEXT NOT NULL,
                created_at REAL NOT NULL,
                verified INTEGER DEFAULT 0
            );
            CREATE TABLE IF NOT EXISTS complaints (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                complaint_id TEXT UNIQUE NOT NULL,
                mobile TEXT NOT NULL,
                title TEXT NOT NULL,
                description TEXT NOT NULL,
                department TEXT NOT NULL,
                location TEXT NOT NULL,
                image_path TEXT,
                status TEXT DEFAULT 'Submitted',
                submitted_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS admins (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                password TEXT NOT NULL
            );
            INSERT OR IGNORE INTO admins (username, password) VALUES ('admin', 'admin123');
        ''')

init_db()

# ── Helpers ──────────────────────────────────────────────────────────────────

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def generate_complaint_id():
    return 'CMP-' + ''.join(random.choices(string.ascii_uppercase + string.digits, k=8))

def generate_otp():
    return str(random.randint(100000, 999999))

def admin_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if not session.get('admin_logged_in'):
            return redirect(url_for('admin_login'))
        return f(*args, **kwargs)
    return decorated

def send_otp_demo(mobile, otp):
    """
    DEMO MODE - OTP prints in terminal.
    For real SMS, replace with Twilio:
        pip install twilio
        from twilio.rest import Client
        client = Client("ACCOUNT_SID", "AUTH_TOKEN")
        client.messages.create(body=f"OTP: {otp}", from_="+1XXXXXXXXXX", to=f"+91{mobile}")
    """
    print(f"\n{'='*50}\n  OTP for {mobile}: {otp}\n{'='*50}\n")

# ── Routes: Home ─────────────────────────────────────────────────────────────

@app.route('/')
def home():
    with get_db() as conn:
        total    = conn.execute('SELECT COUNT(*) FROM complaints').fetchone()[0]
        resolved = conn.execute("SELECT COUNT(*) FROM complaints WHERE status='Resolved'").fetchone()[0]
    return render_template('index.html', total=total, resolved=resolved)

# ── Routes: OTP ──────────────────────────────────────────────────────────────

@app.route('/verify', methods=['GET', 'POST'])
def verify():
    if request.method == 'POST':
        action = request.form.get('action')
        mobile = request.form.get('mobile', '').strip()

        if action == 'send_otp':
            if not mobile or not mobile.isdigit() or len(mobile) < 10:
                return jsonify({'success': False, 'message': 'Please enter a valid 10-digit mobile number.'})
            # Rate limit: max 3 complaints per hour
            with get_db() as conn:
                cutoff = (datetime.now() - timedelta(hours=1)).strftime('%Y-%m-%d %H:%M:%S')
                count  = conn.execute('SELECT COUNT(*) FROM complaints WHERE mobile=? AND submitted_at>?',
                                      (mobile, cutoff)).fetchone()[0]
                if count >= 3:
                    return jsonify({'success': False, 'message': 'Too many complaints from this number. Try again later.'})
            otp = generate_otp()
            send_otp_demo(mobile, otp)
            with get_db() as conn:
                conn.execute('DELETE FROM otps WHERE mobile=?', (mobile,))
                conn.execute('INSERT INTO otps (mobile, otp, created_at) VALUES (?,?,?)',
                             (mobile, otp, time.time()))
            session['pending_mobile'] = mobile
            return jsonify({'success': True, 'message': f'OTP sent to {mobile}! Check the terminal window.'})

        elif action == 'verify_otp':
            otp_input      = request.form.get('otp', '').strip()
            pending_mobile = session.get('pending_mobile')
            if not pending_mobile:
                return jsonify({'success': False, 'message': 'Session expired. Please start again.'})
            with get_db() as conn:
                record = conn.execute(
                    'SELECT * FROM otps WHERE mobile=? AND verified=0 ORDER BY id DESC LIMIT 1',
                    (pending_mobile,)).fetchone()
                if not record:
                    return jsonify({'success': False, 'message': 'OTP not found. Request a new one.'})
                if time.time() - record['created_at'] > 300:
                    return jsonify({'success': False, 'message': 'OTP expired. Request a new one.'})
                if record['otp'] != otp_input:
                    return jsonify({'success': False, 'message': 'Incorrect OTP. Try again.'})
                conn.execute('UPDATE otps SET verified=1 WHERE id=?', (record['id'],))
            session['verified_mobile'] = pending_mobile
            session['otp_verified']    = True
            return jsonify({'success': True, 'redirect': url_for('complaint_form')})

    return render_template('verify_otp.html')

# ── Routes: Complaint Form ────────────────────────────────────────────────────

@app.route('/complaint', methods=['GET', 'POST'])
def complaint_form():
    if not session.get('otp_verified'):
        flash('Please verify your mobile number first.', 'warning')
        return redirect(url_for('verify'))

    if request.method == 'POST':
        title       = request.form.get('title', '').strip()
        description = request.form.get('description', '').strip()
        department  = request.form.get('department', '').strip()
        location    = request.form.get('location', '').strip()
        mobile      = session.get('verified_mobile')

        if not all([title, description, department, location]):
            flash('Please fill all required fields.', 'error')
            return render_template('complaint_form.html')

        image_path = None
        if 'image' in request.files:
            file = request.files['image']
            if file and file.filename and allowed_file(file.filename):
                fname      = secure_filename(file.filename)
                uname      = f"{int(time.time())}_{fname}"
                file.save(os.path.join(app.config['UPLOAD_FOLDER'], uname))
                image_path = uname

        cid = generate_complaint_id()
        now = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        with get_db() as conn:
            conn.execute(
                'INSERT INTO complaints (complaint_id,mobile,title,description,department,location,image_path,submitted_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?)',
                (cid, mobile, title, description, department, location, image_path, now, now))

        session.pop('otp_verified',    None)
        session.pop('verified_mobile', None)
        session.pop('pending_mobile',  None)
        return render_template('complaint_form.html', success=True, complaint_id=cid)

    return render_template('complaint_form.html')

# ── Routes: Track ─────────────────────────────────────────────────────────────

@app.route('/track', methods=['GET', 'POST'])
def track():
    complaint = None
    error     = None
    cid_val   = request.args.get('id', '')
    if request.method == 'POST':
        cid_val = request.form.get('complaint_id', '').strip().upper()
        with get_db() as conn:
            complaint = conn.execute('SELECT * FROM complaints WHERE complaint_id=?', (cid_val,)).fetchone()
        if not complaint:
            error = f'No complaint found with ID: {cid_val}'
    return render_template('track.html', complaint=complaint, error=error, cid_val=cid_val)

# ── Routes: Admin ─────────────────────────────────────────────────────────────

@app.route('/admin/login', methods=['GET', 'POST'])
def admin_login():
    if session.get('admin_logged_in'):
        return redirect(url_for('admin_panel'))
    error = None
    if request.method == 'POST':
        u = request.form.get('username', '').strip()
        p = request.form.get('password', '').strip()
        with get_db() as conn:
            row = conn.execute('SELECT * FROM admins WHERE username=? AND password=?', (u, p)).fetchone()
        if row:
            session['admin_logged_in'] = True
            session['admin_username']  = u
            return redirect(url_for('admin_panel'))
        error = 'Invalid username or password.'
    return render_template('admin_login.html', error=error)

@app.route('/admin/logout')
def admin_logout():
    session.clear()
    return redirect(url_for('admin_login'))

@app.route('/admin')
@admin_required
def admin_panel():
    sf = request.args.get('status', '')
    df = request.args.get('dept', '')
    q  = 'SELECT * FROM complaints WHERE 1=1'
    p  = []
    if sf: q += ' AND status=?';     p.append(sf)
    if df: q += ' AND department=?'; p.append(df)
    q += ' ORDER BY submitted_at DESC'
    with get_db() as conn:
        complaints  = conn.execute(q, p).fetchall()
        stats = {
            'total':     conn.execute('SELECT COUNT(*) FROM complaints').fetchone()[0],
            'submitted': conn.execute("SELECT COUNT(*) FROM complaints WHERE status='Submitted'").fetchone()[0],
            'review':    conn.execute("SELECT COUNT(*) FROM complaints WHERE status='Under Review'").fetchone()[0],
            'progress':  conn.execute("SELECT COUNT(*) FROM complaints WHERE status='In Progress'").fetchone()[0],
            'resolved':  conn.execute("SELECT COUNT(*) FROM complaints WHERE status='Resolved'").fetchone()[0],
        }
        depts = conn.execute('SELECT DISTINCT department FROM complaints ORDER BY department').fetchall()
    return render_template('admin.html', complaints=complaints, stats=stats, depts=depts,
                           status_filter=sf, dept_filter=df)

@app.route('/admin/update_status', methods=['POST'])
@admin_required
def update_status():
    cid    = request.form.get('complaint_id')
    status = request.form.get('status')
    if status not in ['Submitted', 'Under Review', 'In Progress', 'Resolved']:
        return jsonify({'success': False, 'message': 'Invalid status'})
    now = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    with get_db() as conn:
        conn.execute('UPDATE complaints SET status=?, updated_at=? WHERE complaint_id=?', (status, now, cid))
    return jsonify({'success': True, 'message': 'Status updated!'})

@app.route('/admin/delete/<cid>', methods=['POST'])
@admin_required
def delete_complaint(cid):
    with get_db() as conn:
        row = conn.execute('SELECT image_path FROM complaints WHERE complaint_id=?', (cid,)).fetchone()
        if row and row['image_path']:
            fp = os.path.join(app.config['UPLOAD_FOLDER'], row['image_path'])
            if os.path.exists(fp): os.remove(fp)
        conn.execute('DELETE FROM complaints WHERE complaint_id=?', (cid,))
    return jsonify({'success': True, 'message': 'Deleted!'})

@app.route('/admin/image/<filename>')
@admin_required
def view_image(filename):
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename)

if __name__ == '__main__':
    print("\n" + "="*55)
    print("  Anonymous Complaint System")
    print("  Open browser: http://127.0.0.1:5000")
    print("  Admin Panel:  http://127.0.0.1:5000/admin/login")
    print("  Admin Login:  admin / admin123")
    print("="*55 + "\n")
    app.run(debug=True, port=5000)
