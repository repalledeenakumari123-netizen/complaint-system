/* ── Toast ───────────────────────────────────────────────── */
function showToast(msg, type = 'success') {
  let wrap = document.querySelector('.toast-wrap');
  if (!wrap) { wrap = document.createElement('div'); wrap.className = 'toast-wrap'; document.body.appendChild(wrap); }
  const icons = { success: '✅', error: '❌', info: 'ℹ️', warning: '⚠️' };
  const t = document.createElement('div');
  t.className = `toast ${type}`;
  t.innerHTML = `<span>${icons[type] || '📢'}</span><span>${msg}</span>`;
  wrap.appendChild(t);
  setTimeout(() => { t.style.opacity = '0'; t.style.transition = '0.3s'; setTimeout(() => t.remove(), 300); }, 3500);
}

/* ── Hamburger ───────────────────────────────────────────── */
const hb = document.querySelector('.hamburger');
const nl = document.querySelector('.nav-links');
if (hb && nl) hb.addEventListener('click', () => nl.classList.toggle('open'));

/* ── OTP Page ────────────────────────────────────────────── */
const sendBtn    = document.getElementById('sendOtpBtn');
const verifyBtn  = document.getElementById('verifyOtpBtn');
const otpSection = document.getElementById('otpSection');
const mobileInp  = document.getElementById('mobile');
const otpBoxes   = document.querySelectorAll('.otp-box');
const timerEl    = document.getElementById('otpTimer');
const resendBtn  = document.getElementById('resendBtn');
let   timerInt;

/* OTP box keyboard logic */
otpBoxes.forEach((box, i) => {
  box.addEventListener('input', () => {
    box.value = box.value.replace(/\D/g, '').slice(0, 1);
    if (box.value) { box.classList.add('filled'); if (i < otpBoxes.length - 1) otpBoxes[i + 1].focus(); }
    else box.classList.remove('filled');
  });
  box.addEventListener('keydown', e => { if (e.key === 'Backspace' && !box.value && i > 0) otpBoxes[i - 1].focus(); });
  box.addEventListener('paste', e => {
    e.preventDefault();
    const digits = (e.clipboardData.getData('text').replace(/\D/g, '')).slice(0, 6).split('');
    digits.forEach((d, idx) => { if (otpBoxes[idx]) { otpBoxes[idx].value = d; otpBoxes[idx].classList.add('filled'); } });
    const next = Math.min(digits.length, otpBoxes.length - 1);
    otpBoxes[next].focus();
  });
});

function getOtp() { return Array.from(otpBoxes).map(b => b.value).join(''); }

function startTimer(sec) {
  if (!timerEl) return;
  clearInterval(timerInt);
  let r = sec;
  timerEl.textContent = `OTP expires in ${r}s`;
  timerEl.style.display = 'block';
  if (resendBtn) resendBtn.classList.add('hidden');
  timerInt = setInterval(() => {
    r--;
    timerEl.textContent = `OTP expires in ${r}s`;
    if (r <= 0) {
      clearInterval(timerInt);
      timerEl.textContent = 'OTP expired.';
      if (resendBtn) resendBtn.classList.remove('hidden');
    }
  }, 1000);
}

function updateSteps(step) {
  document.querySelectorAll('.step-dot').forEach((d, i) => {
    d.classList.remove('active', 'done');
    if (i + 1 < step) d.classList.add('done');
    else if (i + 1 === step) d.classList.add('active');
  });
  document.querySelectorAll('.step-line').forEach((l, i) => l.classList.toggle('done', i + 1 < step));
}

async function doSendOtp() {
  const mobile = mobileInp ? mobileInp.value.trim() : '';
  if (!mobile || !/^\d{10}$/.test(mobile)) { showToast('Please enter a valid 10-digit mobile number.', 'error'); return; }
  const btn = sendBtn || resendBtn;
  const orig = btn ? btn.innerHTML : '';
  if (btn) { btn.innerHTML = '<span class="spinner"></span> Sending...'; btn.disabled = true; }
  try {
    const fd = new FormData(); fd.append('action', 'send_otp'); fd.append('mobile', mobile);
    const res  = await fetch('/verify', { method: 'POST', body: fd });
    const data = await res.json();
    if (data.success) {
      showToast(data.message, 'success');
      if (otpSection) otpSection.classList.remove('hidden');
      if (mobileInp) mobileInp.disabled = true;
      startTimer(300);
      updateSteps(2);
    } else { showToast(data.message, 'error'); }
  } catch { showToast('Network error. Try again.', 'error'); }
  finally { if (btn) { btn.innerHTML = orig; btn.disabled = false; } }
}

if (sendBtn)   sendBtn.addEventListener('click', doSendOtp);
if (resendBtn) resendBtn.addEventListener('click', doSendOtp);

if (verifyBtn) {
  verifyBtn.addEventListener('click', async () => {
    const otp = getOtp();
    if (otp.length < 6) { showToast('Please enter the complete 6-digit OTP.', 'error'); return; }
    const orig = verifyBtn.innerHTML;
    verifyBtn.innerHTML = '<span class="spinner"></span> Verifying...';
    verifyBtn.disabled  = true;
    try {
      const fd = new FormData(); fd.append('action', 'verify_otp'); fd.append('otp', otp);
      const res  = await fetch('/verify', { method: 'POST', body: fd });
      const data = await res.json();
      if (data.success) {
        showToast('OTP verified! Redirecting...', 'success');
        clearInterval(timerInt);
        setTimeout(() => window.location.href = data.redirect, 900);
      } else {
        showToast(data.message, 'error');
        otpBoxes.forEach(b => { b.value = ''; b.classList.remove('filled'); });
        otpBoxes[0] && otpBoxes[0].focus();
        verifyBtn.innerHTML = '🔓 Verify OTP'; verifyBtn.disabled = false;
      }
    } catch { showToast('Network error.', 'error'); verifyBtn.innerHTML = orig; verifyBtn.disabled = false; }
  });
}

/* ── Complaint form upload preview ──────────────────────── */
const imgInp  = document.getElementById('imageInput');
const imgPrev = document.getElementById('imagePreview');
const uplLbl  = document.getElementById('uploadLabel');
if (imgInp) {
  imgInp.addEventListener('change', () => {
    const file = imgInp.files[0];
    if (file) {
      const r = new FileReader();
      r.onload = e => { if (imgPrev) { imgPrev.src = e.target.result; imgPrev.style.display = 'block'; } if (uplLbl) uplLbl.textContent = `📎 ${file.name}`; };
      r.readAsDataURL(file);
    }
  });
}

/* ── Copy complaint ID ───────────────────────────────────── */
function copyId() {
  const el = document.querySelector('.cid-badge');
  if (el) navigator.clipboard.writeText(el.textContent.trim()).then(() => showToast('Complaint ID copied!', 'success'));
}

/* ── Admin: update status ────────────────────────────────── */
async function updateStatus(cid, sel) {
  try {
    const fd = new FormData(); fd.append('complaint_id', cid); fd.append('status', sel.value);
    const res  = await fetch('/admin/update_status', { method: 'POST', body: fd });
    const data = await res.json();
    showToast(data.message, data.success ? 'success' : 'error');
    if (data.success) {
      const row = sel.closest('tr');
      if (row) {
        const cell = row.querySelector('.status-cell');
        if (cell) cell.innerHTML = buildBadge(sel.value);
      }
    }
  } catch { showToast('Error updating status.', 'error'); }
}

function buildBadge(s) {
  const cls = { 'Submitted': 's-submitted', 'Under Review': 's-under-review', 'In Progress': 's-in-progress', 'Resolved': 's-resolved' };
  const ico = { 'Submitted': '●', 'Under Review': '●', 'In Progress': '●', 'Resolved': '✓' };
  return `<span class="status-badge ${cls[s] || ''}">${ico[s] || '●'} ${s}</span>`;
}

/* ── Admin: delete ───────────────────────────────────────── */
async function deleteComplaint(cid) {
  if (!confirm(`Delete complaint ${cid}? This cannot be undone.`)) return;
  try {
    const res  = await fetch(`/admin/delete/${cid}`, { method: 'POST' });
    const data = await res.json();
    if (data.success) { showToast('Complaint deleted.', 'success'); const row = document.getElementById(`row-${cid}`); if (row) row.remove(); }
    else showToast(data.message, 'error');
  } catch { showToast('Error deleting.', 'error'); }
}

/* ── Admin: view image modal ─────────────────────────────── */
function viewImage(filename) {
  const modal = document.getElementById('imgModal');
  const img   = document.getElementById('modalImg');
  if (modal && img) { img.src = `/admin/image/${filename}`; modal.classList.add('open'); }
}
function closeModal() {
  const modal = document.getElementById('imgModal');
  if (modal) modal.classList.remove('open');
}
document.addEventListener('click', e => { const m = document.getElementById('imgModal'); if (m && e.target === m) closeModal(); });

/* ── Animate count numbers ───────────────────────────────── */
document.addEventListener('DOMContentLoaded', () => {
  document.querySelectorAll('[data-count]').forEach(el => {
    const target = parseInt(el.dataset.count, 10) || 0;
    if (target === 0) return;
    let cur = 0;
    const step = Math.max(1, Math.floor(target / 25));
    const iv = setInterval(() => { cur = Math.min(cur + step, target); el.textContent = cur; if (cur >= target) clearInterval(iv); }, 40);
  });
});
