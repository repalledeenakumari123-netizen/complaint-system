# 🛡️ Anonymous Complaint System with OTP Verification

A full-stack web application for anonymous complaint submission with OTP-based verification and fake complaint prevention.

---

## 📁 Project Structure

```
complaint_system/
├── app.py                  ← Main Flask application
├── database.db             ← SQLite database (auto-created)
├── requirements.txt        ← Python dependencies
├── templates/
│   ├── base.html           ← Shared layout + navbar
│   ├── index.html          ← Landing page
│   ├── verify_otp.html     ← Mobile OTP verification
│   ├── complaint_form.html ← Complaint submission form
│   ├── track.html          ← Complaint tracking page
│   ├── admin_login.html    ← Admin login
│   └── admin.html          ← Admin dashboard
└── static/
    ├── css/
    │   └── style.css       ← All styles
    ├── js/
    │   └── main.js         ← All JavaScript
    └── uploads/            ← Uploaded evidence files
```

---

## 🚀 How to Run

### Step 1 — Install Python
Make sure Python 3.8+ is installed:
```bash
python --version
```

### Step 2 — Create a Virtual Environment (Recommended)
```bash
cd complaint_system
python -m venv venv

# Activate on Windows:
venv\Scripts\activate

# Activate on Mac/Linux:
source venv/bin/activate
```

### Step 3 — Install Dependencies
```bash
pip install -r requirements.txt
```

### Step 4 — Run the Application
```bash
python app.py
```

### Step 5 — Open in Browser
Visit: **http://127.0.0.1:5000**

---

## 🔑 Default Admin Credentials
- **Username:** `admin`
- **Password:** `admin123`

Admin Panel URL: http://127.0.0.1:5000/admin/login

---

## 📱 OTP Demo Mode
In demo mode, OTPs are printed to the **terminal/console** where Flask is running.
Look for output like:
```
==================================================
  📱 OTP for 9876543210: 482910
==================================================
```

### To use Real SMS (Twilio):
1. Install Twilio: `pip install twilio`
2. Get credentials from https://www.twilio.com
3. Replace the `send_otp()` function in `app.py`:

```python
from twilio.rest import Client

def send_otp(mobile, otp):
    client = Client("YOUR_ACCOUNT_SID", "YOUR_AUTH_TOKEN")
    client.messages.create(
        body=f"Your ACS complaint verification OTP is: {otp}. Valid for 5 minutes.",
        from_="+1XXXXXXXXXX",  # Your Twilio number
        to=f"+91{mobile}"
    )
    return True
```

---

## ✨ Features

| Feature | Details |
|---------|---------|
| 🔐 OTP Verification | 6-digit OTP, 5-minute expiry |
| 🤖 Anti-Fake | Max 3 complaints/hour per number |
| 🛡️ Anonymity | Mobile number masked in admin view |
| 📎 Evidence Upload | Images/PDF up to 16MB |
| 🔍 Complaint Tracking | Unique CMP-XXXXXXXX IDs |
| ⚙️ Admin Dashboard | Stats, filters, status updates, delete |
| 📊 Statistics | Live complaint count charts |
| 📱 Responsive | Works on mobile and desktop |

---

## 🛣️ Pages

| URL | Description |
|-----|-------------|
| `/` | Home / Landing page |
| `/verify` | Mobile OTP verification |
| `/complaint` | Complaint form (requires OTP) |
| `/track` | Track complaint by ID |
| `/admin/login` | Admin login |
| `/admin` | Admin dashboard (requires login) |

---

## 🔒 Security Notes

- Change `app.secret_key` in `app.py` before deploying to production
- Change default admin password in the database or `init_db()` function
- Use HTTPS in production
- Consider adding CSRF protection with `flask-wtf`
